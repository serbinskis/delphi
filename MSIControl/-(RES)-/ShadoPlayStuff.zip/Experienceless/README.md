

# Experienceless
A Shadowplay API client

![Expirienceless Screenshot](https://i.imgur.com/4sFifgB.png)

**Pre requirements**

You'll need installed Geforce Expirience client for this to work

**Setup**

* Kill "Nvidia Web Helper.exe" process from Task Manager
* Stop service "NvContainerLocalSystem" from Task Manager
* Remove "C:\Program Files (x86)\NVIDIA Corporation\NvNode" folder
* Remove content of "C:\Program Files\NVIDIA Corporation\NVIDIA GeForce Experience"
* Extract "NVIDIA Share.exe" from release to "C:\Program Files\NVIDIA Corporation\NVIDIA GeForce Experience"
* Start service "NvContainerLocalSystem" from Task Manager
* Extract rest of release to folder of your choice and run Experienceless.exe
