#include <iostream>
#include <sstream>
#include <algorithm>
#include "ec.hpp"

BYTE hex2byte(const std::string& _str) {
    return std::stoul(_str, nullptr, 16);
}

std::string byte2hex(int byte) {
    std::stringstream stream;
    stream << std::hex << byte;
    std::string result(stream.str());
    std::transform(result.begin(), result.end(), result.begin(), ::toupper);
    return result;
}

int main(int argc, char** argv)
{
    if (argc <= 1) {
        std::cout << "EmbeddedController print (Print dump of EC)\n";
        std::cout << "EmbeddedController save dump.bin (Save dump of EC)\n";
        std::cout << "EmbeddedController invert 0x01 (Invert value of register 0x01)\n";
        std::cout << "EmbeddedController read 0x01 (Read value of register 0x01)\n";
        std::cout << "EmbeddedController write 0x01 0x02 (Write value of 0x02 to register 0x01)\n";
        exit(0);
    }

    EmbeddedController ec = EmbeddedController();
    if (!ec.driverFileExist || !ec.driverLoaded) { exit(-1); }

    //Print EC dump
    if (strcmp(argv[1], "print") == 0) {
        ec.printDump();
        ec.close();
    }

    //Save EC dump
    if ((strcmp(argv[1], "save") == 0) && (argc >= 3)) {
        ec.saveDump(argv[2]);
        ec.close();
    }

    //Invert byte from address
    if ((strcmp(argv[1], "invert") == 0) && (argc >= 3)) {
        BYTE byte = ec.readByte(hex2byte(argv[2]));
        bool written = ec.writeByte(hex2byte(argv[2]), ~byte);
        ec.close();
        std::cout << written;
        exit(written);
    }

    //Read byte from address
    if ((strcmp(argv[1], "read") == 0) && (argc >= 3)) {
        BYTE byte = ec.readByte(hex2byte(argv[2]));
        ec.close();
        std::cout << "0x" + byte2hex(byte);
        exit(byte);
    }

    //Write byte to address
    if ((strcmp(argv[1], "write") == 0) && (argc >= 4)) {
        bool written = ec.writeByte(hex2byte(argv[2]), hex2byte(argv[3]));
        ec.close();
        std::cout << written;
        exit(written);
    }
}